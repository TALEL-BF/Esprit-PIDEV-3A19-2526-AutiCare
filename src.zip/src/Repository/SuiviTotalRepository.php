<?php

namespace App\Repository;

use App\Entity\SuiviTotal;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<SuiviTotal>
 */
class SuiviTotalRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, SuiviTotal::class);
    }

    /**
     * @return SuiviTotal[]
     */
    public function searchAndFilter(?string $search, ?string $niveau, ?string $tri): array
    {
        $qb = $this->createQueryBuilder('s')
            ->leftJoin('s.niveauJeu', 'n')
            ->addSelect('n');

        if ($search !== null && trim($search) !== '') {
            $qb->andWhere('CAST(s.enfantId AS string) LIKE :search OR s.remarque LIKE :search')
               ->setParameter('search', '%' . trim($search) . '%');
        }

        if ($niveau !== null && trim($niveau) !== '') {
            $qb->andWhere('UPPER(n.libelle) = :niveau')
               ->setParameter('niveau', strtoupper(trim($niveau)));
        }

        switch ($tri) {
            case 'moyenne_asc':
                $qb->orderBy('s.moyenne', 'ASC');
                break;
            case 'moyenne_desc':
                $qb->orderBy('s.moyenne', 'DESC');
                break;
            case 'id_asc':
                $qb->orderBy('s.id', 'ASC');
                break;
            case 'id_desc':
            default:
                $qb->orderBy('s.id', 'DESC');
                break;
        }

        return $qb->getQuery()->getResult();
    }
}