<?php

namespace App\Controller;

use App\Entity\NiveauJeu;
use App\Form\NiveauJeuType;
use App\Repository\NiveauJeuRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

#[Route('/niveau/jeu')]
final class NiveauJeuController extends AbstractController
{
    #[Route(name: 'app_niveau_jeu_index', methods: ['GET'])]
    public function index(Request $request, NiveauJeuRepository $niveauJeuRepository): Response
    {
        $search = $request->query->get('search');
        $niveau = $request->query->get('niveau');
        $tri = $request->query->get('tri', 'id_desc');

        $niveauJeus = $niveauJeuRepository->searchAndFilter($search, $niveau, $tri);

        return $this->render('niveau_jeu/index.html.twig', [
            'niveau_jeus' => $niveauJeus,
            'current_search' => $search,
            'current_niveau' => $niveau,
            'current_tri' => $tri,
        ]);
    }

    #[Route('/new', name: 'app_niveau_jeu_new', methods: ['GET', 'POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $niveauJeu = new NiveauJeu();
        $form = $this->createForm(NiveauJeuType::class, $niveauJeu);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($niveauJeu);
            $entityManager->flush();

            $this->addFlash('success', 'Le niveau a été ajouté avec succès.');

            return $this->redirectToRoute('app_niveau_jeu_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('niveau_jeu/new.html.twig', [
            'niveau_jeu' => $niveauJeu,
            'form' => $form->createView(),
        ]);
    }

    #[Route('/{id}', name: 'app_niveau_jeu_show', methods: ['GET'])]
    public function show(NiveauJeu $niveauJeu): Response
    {
        return $this->render('niveau_jeu/show.html.twig', [
            'niveau_jeu' => $niveauJeu,
        ]);
    }

    #[Route('/{id}/edit', name: 'app_niveau_jeu_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, NiveauJeu $niveauJeu, EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(NiveauJeuType::class, $niveauJeu);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            $this->addFlash('success', 'Le niveau a été modifié avec succès.');

            return $this->redirectToRoute('app_niveau_jeu_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('niveau_jeu/edit.html.twig', [
            'niveau_jeu' => $niveauJeu,
            'form' => $form->createView(),
        ]);
    }

    #[Route('/{id}', name: 'app_niveau_jeu_delete', methods: ['POST'])]
    public function delete(Request $request, NiveauJeu $niveauJeu, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('delete' . $niveauJeu->getId(), $request->request->get('_token'))) {
            $entityManager->remove($niveauJeu);
            $entityManager->flush();

            $this->addFlash('success', 'Le niveau a été supprimé avec succès.');
        }

        return $this->redirectToRoute('app_niveau_jeu_index', [], Response::HTTP_SEE_OTHER);
    }
}