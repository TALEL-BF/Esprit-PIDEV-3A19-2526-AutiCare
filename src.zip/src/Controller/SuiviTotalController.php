<?php

namespace App\Controller;

use App\Entity\SuiviTotal;
use App\Form\SuiviTotalType;
use App\Repository\SuiviTotalRepository;
use App\Service\NiveauResolverService;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

#[Route('/suivi/total')]
final class SuiviTotalController extends AbstractController
{
    #[Route(name: 'app_suivi_total_index', methods: ['GET'])]
    public function index(Request $request, SuiviTotalRepository $suiviTotalRepository): Response
    {
        $search = $request->query->get('search');
        $niveau = $request->query->get('niveau');
        $tri = $request->query->get('tri', 'id_desc');

        $suiviTotals = $suiviTotalRepository->searchAndFilter($search, $niveau, $tri);

        return $this->render('suivi_total/index.html.twig', [
            'suivi_totals' => $suiviTotals,
            'current_search' => $search,
            'current_niveau' => $niveau,
            'current_tri' => $tri,
        ]);
    }

    #[Route('/new', name: 'app_suivi_total_new', methods: ['GET', 'POST'])]
    public function new(
        Request $request,
        EntityManagerInterface $entityManager,
        NiveauResolverService $niveauResolverService
    ): Response {
        $suiviTotal = new SuiviTotal();
        $form = $this->createForm(SuiviTotalType::class, $suiviTotal);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $niveau = $niveauResolverService->findByMoyenne((float) $suiviTotal->getMoyenne());

            if ($niveau === null) {
                $this->addFlash('danger', 'Aucun niveau ne correspond à cette moyenne.');

                return $this->render('suivi_total/new.html.twig', [
                    'suivi_total' => $suiviTotal,
                    'form' => $form->createView(),
                ]);
            }

            $suiviTotal->setNiveauJeu($niveau);

            $entityManager->persist($suiviTotal);
            $entityManager->flush();

            $this->addFlash('success', 'Le suivi a été ajouté avec succès.');

            return $this->redirectToRoute('app_suivi_total_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('suivi_total/new.html.twig', [
            'suivi_total' => $suiviTotal,
            'form' => $form->createView(),
        ]);
    }

    #[Route('/{id}', name: 'app_suivi_total_show', methods: ['GET'])]
    public function show(SuiviTotal $suiviTotal): Response
    {
        return $this->render('suivi_total/show.html.twig', [
            'suivi_total' => $suiviTotal,
        ]);
    }

    #[Route('/{id}/edit', name: 'app_suivi_total_edit', methods: ['GET', 'POST'])]
    public function edit(
        Request $request,
        SuiviTotal $suiviTotal,
        EntityManagerInterface $entityManager,
        NiveauResolverService $niveauResolverService
    ): Response {
        $form = $this->createForm(SuiviTotalType::class, $suiviTotal);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $niveau = $niveauResolverService->findByMoyenne((float) $suiviTotal->getMoyenne());

            if ($niveau === null) {
                $this->addFlash('danger', 'Aucun niveau ne correspond à cette moyenne.');

                return $this->render('suivi_total/edit.html.twig', [
                    'suivi_total' => $suiviTotal,
                    'form' => $form->createView(),
                ]);
            }

            $suiviTotal->setNiveauJeu($niveau);

            $entityManager->flush();

            $this->addFlash('success', 'Le suivi a été modifié avec succès.');

            return $this->redirectToRoute('app_suivi_total_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('suivi_total/edit.html.twig', [
            'suivi_total' => $suiviTotal,
            'form' => $form->createView(),
        ]);
    }

    #[Route('/{id}', name: 'app_suivi_total_delete', methods: ['POST'])]
    public function delete(Request $request, SuiviTotal $suiviTotal, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('delete' . $suiviTotal->getId(), $request->request->get('_token'))) {
            $entityManager->remove($suiviTotal);
            $entityManager->flush();

            $this->addFlash('success', 'Le suivi a été supprimé avec succès.');
        }

        return $this->redirectToRoute('app_suivi_total_index', [], Response::HTTP_SEE_OTHER);
    }
}